# נבון ביזנעס — פרויקט Android Studio מלא (עברית + קיזוזים)

## מה יש כאן
- אפליקציה בעברית מלאה (Compose + Room)
- מסכים: רישום, פעולות, קיזוזים, סיכום, ייצוא CSV
- חישוב נטו: סה״כ פעולות – סה״כ קיזוזים
- אייקון בצורת מחשבון
- שם האפליקציה: נבון ביזנעס

## איך בונים APK
1. פתח/י ב־Android Studio (File → Open).
2. המתן/י ל־Gradle Sync.
3. Build → Build APK(s).
4. הקובץ יופיע תחת: `app/build/outputs/apk/debug/app-debug.apk`.
