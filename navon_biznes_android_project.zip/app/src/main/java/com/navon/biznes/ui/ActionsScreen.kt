
package com.navon.biznes.ui

import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.navon.biznes.data.*
import kotlinx.coroutines.launch

@Composable
fun ActionsScreen(vm: ActionsViewModel = viewModel()) {
    val scope = rememberCoroutineScope()
    val actions by vm.actions.collectAsState(initial = emptyList())

    var name by remember { mutableStateOf("") }
    var rateText by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("ניהול פעולות (שם + תעריף ליחידה)", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("שם הפעולה") }, modifier = Modifier.weight(1f))
            OutlinedTextField(rateText, { rateText = it }, label = { Text("תעריף (₪)") }, modifier = Modifier.weight(1f))
            Button(onClick = {
                val rate = rateText.toDoubleOrNull() ?: 0.0
                if (name.isNotBlank() && rate > 0.0) {
                    scope.launch { vm.add(name.trim(), rate) }
                    name = ""; rateText = ""
                }
            }) { Text("הוסף") }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(actions, key = { it.id }) { a ->
                ElevatedCard {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(a.name, style = MaterialTheme.typography.titleSmall)
                            Text("₪ %.2f ליח׳".format(a.rate))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                name = a.name; rateText = a.rate.toString()
                                scope.launch { vm.delete(a) }
                            }) { Text("ערוך") }
                            OutlinedButton(onClick = { scope.launch { vm.delete(a) } }) { Text("מחק") }
                        }
                    }
                }
            }
        }
    }
}

class ActionsViewModel : androidx.lifecycle.ViewModel() {
    private val dao = LocalDbProvider.db().actionDao()
    val actions = dao.observeAll()
    suspend fun add(name: String, rate: Double) { dao.insert(ActionType(name = name, rate = rate)) }
    suspend fun delete(a: ActionType) { dao.delete(a) }
}
