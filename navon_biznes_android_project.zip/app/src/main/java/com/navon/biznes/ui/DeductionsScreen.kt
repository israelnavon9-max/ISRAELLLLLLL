
package com.navon.biznes.ui

import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.navon.biznes.data.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun DeductionsScreen(vm: DeductionsViewModel = viewModel()) {
    val scope = rememberCoroutineScope()
    val date by vm.currentDate.collectAsState()
    val deds by vm.deductionsForDate.collectAsState(initial = emptyList())

    var desc by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }

    val sum = deds.sumOf { it.amount }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.prevDay() }) { Text("◀ יום קודם") }
            Text(date, modifier = Modifier.padding(8.dp))
            OutlinedButton(onClick = { vm.nextDay() }) { Text("יום הבא ▶") }
            Spacer(Modifier.weight(1f))
            Text("סה\"כ קיזוזים ליום: ₪ %.2f".format(sum))
        }
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(desc, { desc = it }, label = { Text("תיאור קיזוז") }, modifier = Modifier.weight(2f))
            OutlinedTextField(amountText, { amountText = it }, label = { Text("סכום (₪)") }, modifier = Modifier.weight(1f))
            Button(onClick = {
                val amt = amountText.toDoubleOrNull() ?: 0.0
                if (desc.isNotBlank() && amt > 0.0) {
                    scope.launch { vm.addDeduction(desc.trim(), amt) }
                    desc = ""; amountText = ""
                }
            }) { Text("הוסף") }
        }

        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(deds, key = { it.id }) { d ->
                ElevatedCard {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) { Text(d.description) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("- ₪ %.2f".format(d.amount))
                            OutlinedButton(onClick = { scope.launch { vm.delete(d) } }) { Text("מחק") }
                        }
                    }
                }
            }
        }
    }
}

class DeductionsViewModel : androidx.lifecycle.ViewModel() {
    private val dao = LocalDbProvider.db().deductionDao()
    private val fmt = DateTimeFormatter.ISO_DATE
    private val _currentDate = mutableStateOf(LocalDate.now().format(fmt))
    val currentDate: State<String> = _currentDate
    val deductionsForDate = dao.observeByDate(_currentDate.value)

    fun prevDay() { _currentDate.value = LocalDate.parse(_currentDate.value).minusDays(1).format(fmt) }
    fun nextDay() { _currentDate.value = LocalDate.parse(_currentDate.value).plusDays(1).format(fmt) }

    suspend fun addDeduction(desc: String, amount: Double) {
        dao.insert(Deduction(date = _currentDate.value, description = desc, amount = amount))
    }
    suspend fun delete(d: Deduction) { dao.delete(d) }
}
