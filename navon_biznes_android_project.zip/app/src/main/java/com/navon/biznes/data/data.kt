
package com.navon.biznes.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Entity(tableName = "action_types")
data class ActionType(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val rate: Double // ₪ per unit
)

@Entity(
    tableName = "log_entries",
    foreignKeys = [ForeignKey(
        entity = ActionType::class,
        parentColumns = ["id"],
        childColumns = ["actionId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("actionId")]
)
data class LogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,   // yyyy-MM-dd
    val actionId: Long,
    val qty: Double,
    val note: String = ""
)

data class LogWithAction(
    @Embedded val entry: LogEntry,
    @Relation(parentColumn = "actionId", entityColumn = "id")
    val action: ActionType
) {
    val amount: Double get() = action.rate * entry.qty
}

@Entity(tableName = "deductions")
data class Deduction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,    // yyyy-MM-dd
    val description: String,
    val amount: Double   // positive ₪ (will be subtracted)
)

@Dao
interface ActionDao {
    @Query("SELECT * FROM action_types ORDER BY name")
    fun observeAll(): Flow<List<ActionType>>
    @Insert suspend fun insert(a: ActionType): Long
    @Update suspend fun update(a: ActionType)
    @Delete suspend fun delete(a: ActionType)
}

@Dao
interface LogDao {
    @Transaction
    @Query("SELECT * FROM log_entries WHERE date = :date ORDER BY id DESC")
    fun observeByDate(date: String): Flow<List<LogWithAction>>

    @Transaction
    @Query("""
        SELECT * FROM log_entries
        WHERE date BETWEEN :start AND :end
        ORDER BY date ASC, id ASC
    """)
    suspend fun between(start: String, end: String): List<LogWithAction>

    @Insert suspend fun insert(e: LogEntry): Long
    @Delete suspend fun delete(e: LogEntry)
}

@Dao
interface DeductionDao {
    @Query("SELECT * FROM deductions WHERE date = :date ORDER BY id DESC")
    fun observeByDate(date: String): Flow<List<Deduction>>

    @Query("""
        SELECT * FROM deductions 
        WHERE date BETWEEN :start AND :end
        ORDER BY date ASC, id ASC
    """)
    suspend fun between(start: String, end: String): List<Deduction>

    @Insert suspend fun insert(d: Deduction): Long
    @Delete suspend fun delete(d: Deduction)
}

@Database(entities = [ActionType::class, LogEntry::class, Deduction::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun actionDao(): ActionDao
    abstract fun logDao(): LogDao
    abstract fun deductionDao(): DeductionDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getInstance(ctx: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(ctx, AppDatabase::class.java, "navon_biznes.db").build()
                    .also { INSTANCE = it }
            }
    }
}

object LocalDbProvider {
    private var db: AppDatabase? = null
    fun initialize(database: AppDatabase) { db = database }
    fun db(): AppDatabase = requireNotNull(db) { "DB not initialized" }
}
