
package com.navon.biznes.util

import android.content.Context
import android.net.Uri
import com.navon.biznes.data.LogWithAction
import com.navon.biznes.data.Deduction
import java.io.OutputStreamWriter

object Csv {
    fun write(context: Context, uri: Uri, logs: List<LogWithAction>, deds: List<Deduction>): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                OutputStreamWriter(out, Charsets.UTF_8).use { w ->
                    w.appendLine("type,date,name_or_description,qty,rate,amount,note")
                    logs.forEach { x ->
                        val amt = x.amount
                        val rate = x.action.rate
                        val e = x.entry
                        val safeNote = e.note.replace(",", " ").replace("\n", " ")
                        w.appendLine("פעולה,${e.date},${x.action.name},${e.qty},${rate},${amt},${safeNote}")
                    }
                    deds.forEach { d ->
                        w.appendLine("קיזוז,${d.date},${d.description},,,-${d.amount},")
                    }
                }
            }
            true
        } catch (e: Exception) { e.printStackTrace(); false }
    }
}
