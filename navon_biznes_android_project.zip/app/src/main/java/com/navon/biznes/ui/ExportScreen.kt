
package com.navon.biznes.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.navon.biznes.data.*
import com.navon.biznes.util.Csv
import kotlinx.coroutines.launch
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@Composable
fun ExportScreen(vm: ExportViewModel = viewModel()) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var message by remember { mutableStateOf("") }
    val createFileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val ok = vm.writeCsvTo(ctx, uri)
                message = if (ok) "נשמר בהצלחה" else "שמירה נכשלה"
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(vm.year.toString(), {}, label = { Text("שנה") }, readOnly = true)
            OutlinedTextField(vm.month.toString(), {}, label = { Text("חודש") }, readOnly = true)
            Spacer(Modifier.weight(1f))
            Button(onClick = { vm.prevMonth() }) { Text("◀") }
            Button(onClick = { vm.nextMonth() }) { Text("▶") }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            val name = "navon_biznes_${vm.year}_${vm.month}.csv"
            createFileLauncher.launch(name)
        }) { Text("ייצוא CSV לחודש הנבחר") }
        Spacer(Modifier.height(8.dp))
        Text(message)
    }
}

class ExportViewModel : androidx.lifecycle.ViewModel() {
    private val db = LocalDbProvider.db()
    private val logDao = db.logDao()
    private val dedDao = db.deductionDao()
    private val fmt = DateTimeFormatter.ISO_DATE
    var month by mutableStateOf(YearMonth.now().monthValue)
        private set
    var year by mutableStateOf(YearMonth.now().year)
        private set

    fun prevMonth() {
        val ym = YearMonth.of(year, month).minusMonths(1)
        year = ym.year; month = ym.monthValue
    }
    fun nextMonth() {
        val ym = YearMonth.of(year, month).plusMonths(1)
        year = ym.year; month = ym.monthValue
    }

    suspend fun writeCsvTo(ctx: android.content.Context, uri: Uri): Boolean {
        val ym = YearMonth.of(year, month)
        val start = ym.atDay(1).format(fmt)
        val end = ym.atEndOfMonth().format(fmt)
        val logs = logDao.between(start, end)
        val deds = dedDao.between(start, end)
        return Csv.write(ctx, uri, logs, deds)
    }
}
