
package com.navon.biznes.ui

import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.navon.biznes.data.*
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@Composable
fun SummaryScreen(vm: SummaryViewModel = viewModel()) {
    val month by vm.month.collectAsState()
    val year by vm.year.collectAsState()
    val data by vm.state.collectAsState()

    LaunchedEffect(month, year) { vm.refresh() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(year.toString(), {}, label = { Text("שנה") }, readOnly = true)
            OutlinedTextField(month.toString(), {}, label = { Text("חודש") }, readOnly = true)
            Spacer(Modifier.weight(1f))
            Button(onClick = { vm.prevMonth() }) { Text("◀") }
            Button(onClick = { vm.nextMonth() }) { Text("▶") }
        }
        Spacer(Modifier.height(12.dp))
        Text("סה\"כ פעולות: ₪ %.2f".format(data.totalActions))
        Text("סה\"כ קיזוזים: ₪ %.2f".format(data.totalDeductions))
        Text("נטו לחודש: ₪ %.2f".format(data.net()))
        Spacer(Modifier.height(12.dp))
        ElevatedCard {
            Column(Modifier.padding(12.dp)) {
                Text("פירוט לפי פעולה:")
                data.byAction.entries.sortedBy { it.key }.forEach { (name, amt) ->
                    Text("• $name — ₪ %.2f".format(amt))
                }
            }
        }
    }
}

data class MonthSummary(
    val totalActions: Double = 0.0,
    val totalDeductions: Double = 0.0,
    val byAction: Map<String, Double> = emptyMap()
) {
    fun net() = totalActions - totalDeductions
}

class SummaryViewModel : androidx.lifecycle.ViewModel() {
    private val db = LocalDbProvider.db()
    private val logDao = db.logDao()
    private val dedDao = db.deductionDao()
    private val fmt = DateTimeFormatter.ISO_DATE
    private val _month = mutableStateOf(YearMonth.now().monthValue)
    private val _year = mutableStateOf(YearMonth.now().year)
    val month: State<Int> = _month
    val year: State<Int> = _year

    private val _state = mutableStateOf(MonthSummary())
    val state: State<MonthSummary> = _state

    suspend fun refresh() {
        val ym = YearMonth.of(_year.value, _month.value)
        val start = ym.atDay(1).format(fmt)
        val end = ym.atEndOfMonth().format(fmt)
        val logs = logDao.between(start, end)
        val deds = dedDao.between(start, end)
        val totalActions = logs.sumOf { it.amount }
        val totalDeductions = deds.sumOf { it.amount }
        val byAction = logs.groupBy { it.action.name }.mapValues { (_, v) -> v.sumOf { it.amount } }
        _state.value = MonthSummary(totalActions, totalDeductions, byAction)
    }

    fun prevMonth() {
        val ym = YearMonth.of(_year.value, _month.value).minusMonths(1)
        _year.value = ym.year; _month.value = ym.monthValue
    }
    fun nextMonth() {
        val ym = YearMonth.of(_year.value, _month.value).plusMonths(1)
        _year.value = ym.year; _month.value = ym.monthValue
    }
}
