
package com.navon.biznes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.navon.biznes.ui.*
import com.navon.biznes.data.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LocalDbProvider.initialize(AppDatabase.getInstance(applicationContext))
        setContent {
            MaterialTheme {
                AppNav()
            }
        }
    }
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    Scaffold(
        bottomBar = {
            NavigationBar {
                val current = nav.currentBackStackEntryAsState().value?.destination?.route
                fun item(route: String, label: String) {
                    NavigationBarItem(
                        selected = current == route,
                        onClick = { nav.navigate(route) { launchSingleTop = true } },
                        label = { Text(label) },
                        icon = { }
                    )
                }
                item("log", "רישום")
                item("actions", "פעולות")
                item("deductions", "קיזוזים")
                item("summary", "סיכום")
                item("export", "ייצוא")
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = "log", modifier = Modifier.padding(padding)) {
            composable("log") { DailyLogScreen() }
            composable("actions") { ActionsScreen() }
            composable("deductions") { DeductionsScreen() }
            composable("summary") { SummaryScreen() }
            composable("export") { ExportScreen() }
        }
    }
}
