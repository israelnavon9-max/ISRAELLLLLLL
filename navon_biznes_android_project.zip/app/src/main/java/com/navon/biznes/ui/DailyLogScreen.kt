
package com.navon.biznes.ui

import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.navon.biznes.data.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun DailyLogScreen(vm: DailyLogViewModel = viewModel()) {
    val scope = rememberCoroutineScope()
    val actions by vm.actions.collectAsState(initial = emptyList())
    val date by vm.currentDate.collectAsState()
    val logs by vm.entriesForDate.collectAsState(initial = emptyList())
    val deds by vm.deductionsForDate.collectAsState(initial = emptyList())

    var qtyText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var selectedActionId by remember { mutableStateOf<Long?>(null) }

    var dedDesc by remember { mutableStateOf("") }
    var dedAmount by remember { mutableStateOf("") }

    val sumActions = logs.sumOf { it.amount }
    val sumDeds = deds.sumOf { it.amount }
    val net = sumActions - sumDeds

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.prevDay() }) { Text("◀ יום קודם") }
            Text(date, modifier = Modifier.padding(8.dp))
            OutlinedButton(onClick = { vm.nextDay() }) { Text("יום הבא ▶") }
            Spacer(Modifier.weight(1f))
            Column {
                Text("סה\"כ פעולות: ₪ %.2f".format(sumActions))
                Text("סה\"כ קיזוזים: ₪ %.2f".format(sumDeds))
                Text("נטו ליום: ₪ %.2f".format(net))
            }
        }
        Spacer(Modifier.height(12.dp))

        Text("הוסף רישום פעולה", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            var expanded by remember { mutableStateOf(false) }
            val selectedName = actions.firstOrNull { it.id == selectedActionId }?.name ?: "בחר פעולה"
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(
                    value = selectedName, onValueChange = {},
                    label = { Text("פעולה") }, readOnly = true,
                    modifier = Modifier.menuAnchor().weight(1f)
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    actions.forEach { a ->
                        DropdownMenuItem(text = { Text(a.name) }, onClick = {
                            selectedActionId = a.id; expanded = false
                        })
                    }
                }
            }
            OutlinedTextField(qtyText, { qtyText = it }, label = { Text("כמות") }, modifier = Modifier.weight(1f))
            OutlinedTextField(note, { note = it }, label = { Text("הערה") }, modifier = Modifier.weight(1f))
            Button(onClick = {
                val qty = qtyText.toDoubleOrNull() ?: 0.0
                val act = actions.firstOrNull { it.id == selectedActionId }
                if (act != null && qty > 0.0) {
                    scope.launch { vm.addEntry(act.id, qty, note) }
                    qtyText = ""; note = ""
                }
            }) { Text("הוסף") }
        }

        Spacer(Modifier.height(16.dp))
        Text("רישומים ליום", style = MaterialTheme.typography.titleSmall)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(logs, key = { it.entry.id }) { x ->
                ElevatedCard {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("${x.action.name} × ${x.entry.qty}")
                            if (x.entry.note.isNotBlank()) Text(x.entry.note)
                        }
                        Text("₪ %.2f".format(x.amount))
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("קיזוזים ליום", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(dedDesc, { dedDesc = it }, label = { Text("תיאור קיזוז") }, modifier = Modifier.weight(2f))
            OutlinedTextField(dedAmount, { dedAmount = it }, label = { Text("סכום (₪)") }, modifier = Modifier.weight(1f))
            Button(onClick = {
                val amt = dedAmount.toDoubleOrNull() ?: 0.0
                if (dedDesc.isNotBlank() && amt > 0.0) {
                    scope.launch { vm.addDeduction(dedDesc.trim(), amt) }
                    dedDesc = ""; dedAmount = ""
                }
            }) { Text("הוסף קיזוז") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(deds, key = { it.id }) { d ->
                ElevatedCard {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) { Text(d.description) }
                        Text("- ₪ %.2f".format(d.amount))
                    }
                }
            }
        }
    }
}

class DailyLogViewModel : androidx.lifecycle.ViewModel() {
    private val db = LocalDbProvider.db()
    private val actionDao = db.actionDao()
    private val logDao = db.logDao()
    private val dedDao = db.deductionDao()
    private val fmt = DateTimeFormatter.ISO_DATE
    private val _currentDate = mutableStateOf(LocalDate.now().format(fmt))
    val currentDate: State<String> = _currentDate

    val actions = actionDao.observeAll()
    val entriesForDate = logDao.observeByDate(_currentDate.value)
    val deductionsForDate = dedDao.observeByDate(_currentDate.value)

    fun prevDay() { _currentDate.value = LocalDate.parse(_currentDate.value).minusDays(1).format(fmt) }
    fun nextDay() { _currentDate.value = LocalDate.parse(_currentDate.value).plusDays(1).format(fmt) }

    suspend fun addEntry(actionId: Long, qty: Double, note: String) {
        logDao.insert(LogEntry(date = _currentDate.value, actionId = actionId, qty = qty, note = note))
    }
    suspend fun addDeduction(desc: String, amount: Double) {
        dedDao.insert(Deduction(date = _currentDate.value, description = desc, amount = amount))
    }
}
